﻿// Author: Maddison Kiefer
// Class: C# Programming
// This is the main method for the TicTacToe game that is used to get positions, hande exceptions, and replay the game

using System;
using System.Configuration;

namespace TicTacToe
{
    class Program
    {
        static void Main()
        {
            do
            {
                // Start a new game
                var game = new Game();
                var player = 'X';
                // Continue playing until the game ends
                while (!game.Ended())
                {
                    // Display the current state of the game board
                    game.Print();

                    string input;
                    int position;
                    do
                    {
                        //Get an integer position
                        Console.Write("Enter your move:");
                        input = Console.ReadLine();
                        if (!int.TryParse(input, out position))
                        {
                            Console.WriteLine("Position must be in the range 0-8.");
                            Console.Write("Press [Enter]");
                            while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                        }
                    } while (!int.TryParse(input, out position));
                    
                    try
                    {
                        // Handle Exceptions in game.Move()
                        game.Move(position, player);
                    }
                    catch (ArgumentException ex)
                    {
                        // Handle ArgumentException such as invalid position
                        Console.WriteLine("Error: " + ex.Message);
                        Console.Write("Press [Enter]");
                        while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                        // Continue to the next iteration of the loop
                        continue;
                    }
                    catch (BadMoveException ex)
                    {
                        // Handle BadMoveException like attempting to make a move in an occupied cell
                        Console.WriteLine("Error: " + ex.Message);
                        Console.Write("Press [Enter]");
                        while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                        // Continue to the next iteration of the loop
                        continue;
                    }
                    catch (Exception ex)
                    {
                        // Handle unexpected exceptions with a message
                        Console.WriteLine("Unknown Error: " + ex.Message);
                        Console.Write("Press [Enter]");
                        while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                        // Continue to the next iteration of the loop
                        continue;
                    }

                    //Switch players
                    player = (player == 'X') ? 'O' : 'X';
                }

                // Display the final state of the board
                game.Print();

                // Display the result of the game
                if (game.Ended())
                {
                    bool isTie = true;

                    // Check for a winner
                    for (int i = 0; i < 3; i++)
                    {
                        // Check rows and columns for a winner
                        if (game.grid[i, 0] == game.grid[i, 1] && game.grid[i, 1] == game.grid[i, 2] && game.grid[i, 0] != '.')
                        {
                            Console.WriteLine("Player " + game.grid[i, 0] + " wins!");
                            isTie = false;
                            break;
                        }

                        if (game.grid[0, i] == game.grid[1, i] && game.grid[1, i] == game.grid[2, i] && game.grid[0, i] != '.')
                        {
                            Console.WriteLine("Player " + game.grid[0, i] + " wins!");
                            isTie = false;
                            break;
                        }
                    }

                    // Check diagonals for a winner
                    if ((game.grid[0, 0] == game.grid[1, 1] && game.grid[1, 1] == game.grid[2, 2] && game.grid[0, 0] != '.') ||
                        (game.grid[0, 2] == game.grid[1, 1] && game.grid[1, 1] == game.grid[2, 0] && game.grid[0, 2] != '.'))
                    {
                        Console.WriteLine("Player " + game.grid[1, 1] + " wins!");
                        isTie = false;
                    }

                    // If no winner and the grid is full, it's a tie
                    if (isTie)
                    {
                        Console.WriteLine("Tie!");
                    }
                }

                // Ask if the player wants to play again
                Console.Write("Do you want to play again (Type 'y' or 'Y')?");

            } while (Console.ReadKey().Key == ConsoleKey.Y);     
        }
    }
}
