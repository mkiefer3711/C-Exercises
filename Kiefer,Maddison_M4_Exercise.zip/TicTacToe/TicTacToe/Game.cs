﻿// Author: Maddison Kiefer
// Class: C# Programming
// This program will create s simple Tic-Tac-Toe game by creating the grid, checking if there are winners, handling exceptions
// and displaying the grid.

using System;

namespace TicTacToe
{
    internal class Game
    {
        // Represents the tic-tac-toe grid
        public char[,] grid = new char[3, 3];

        // Constructor to initialize the grid with empty cells

        // Checks if the game has ended (win or draw)
        public Game()
        {
            for (int x = 0; x < 3; x++)
            {
                for (int y = 0; y < 3; y++)
                {
                    grid[x, y] = '.';
                }
            }
        }

        public bool Ended()
        {
            // Check for 3 in a row in rows and columns
            for (int i = 0; i < 3; i++)
            {
                // Check rows
                if (grid[i, 0] == grid[i, 1] && grid[i, 1] == grid[i, 2] && grid[i, 0] != '.')
                {
                    // Found a winning row
                    return true;
                }

                // Check columns
                if (grid[0, i] == grid[1, i] && grid[1, i] == grid[2, i] && grid[0, i] != '.')
                {
                    // Found a winning column
                    return true;
                }
            }

            // Check for 3 in a row in diagonals
            if ((grid[0, 0] == grid[1, 1] && grid[1, 1] == grid[2, 2] && grid[0, 0] != '.') ||
                (grid[0, 2] == grid[1, 1] && grid[1, 1] == grid[2, 0] && grid[0, 2] != '.'))
            {
                // Found a winning diagonal
                return true;
            }

            // Check if the grid is full (draw)
            for (int x = 0; x < 3; x++)
            {
                for (int y = 0; y < 3; y++)
                {
                    if (grid[x, y] == '.')
                    {
                        // There is still an empty cell, the game is not over
                        return false;
                    }
                }
            }

            // If no winner and the grid is full, it's a draw
            return true;
        }

        // Performs a player move on the grid
        internal void Move(int position, char player)
        {
            // Checks that input is between 0 and 8
            if (position < 0 || position > 9)
            {
                throw new System.ArgumentException("Position must be in the range 0-8.");
            }

            int row = position / 3;
            int col = position % 3;

            // Checks if the grid cell is already occupied
            if (grid[col, row] != '.')
            {
                throw new BadMoveException("Bad move. That cell is already occupied.");
            }

            // Set the player in the grid cell
            grid[col, row] = player;
        }

        // Prints the current state of the tic-tac-toe grid
        public void Print()
        {
            Console.Clear();

            Console.WriteLine("Key");
            int cell = 0;
            for (int y = 0; y < 3; y++)
            {
                if (y >= 1) Console.WriteLine("---+---+---");
                for (int x = 0; x < 3; x++)
                {
                    if (x >= 1) Console.Write("|");
                    Console.Write(" {0} ", cell++);
                }
                Console.WriteLine();
            }


            Console.WriteLine();
            for (int y = 0; y < 3; y++)
            {
                if (y >= 1) Console.WriteLine("---+---+---");
                for (int x = 0; x < 3; x++)
                {
                    if (x >= 1) Console.Write("|");
                    Console.Write(" {0} ", grid[x, y]);
                }
                Console.WriteLine();
            }

        }

    }

    // Custom exception class for an invalid move
    public class BadMoveException : Exception
    {
        public BadMoveException(string message) : base(message)
        {
        }
    }
}

