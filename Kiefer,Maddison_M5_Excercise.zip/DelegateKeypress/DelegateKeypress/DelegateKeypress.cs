﻿// Author: Maddison Kiefer
// Class: C#
// This program implements a configurable control scheme by associating an input command with an action.
// A delegate is used to store the function to be called.

using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;



namespace DelegateKeypress
{
    class DelegateKeypress
    {
        // Initial positions of the cursor
        private static int x = 20;
        private static int y = 20;

        // Declare the delegate
        public delegate void movement();
        
        // Dictionary to store the association between ConsoleKey and corresponding Action
        private static Dictionary<ConsoleKey, Action> myControls = new Dictionary<ConsoleKey, Action>();

        // Main method
        private static void Main(string[] args)
        {
            // Set up the control scheme
            myControls.Add(ConsoleKey.W, Up);
            myControls.Add(ConsoleKey.S, Down);
            myControls.Add(ConsoleKey.A, Left);
            myControls.Add(ConsoleKey.D, Right);

            // Loop for movement
            while (true)
            {
                // Set the cursor position and display the character '@'
                Console.SetCursorPosition(x, y);
                Console.Write("@");

                // Read a key from the console without displaying it
                var key = Console.ReadKey(true);

                // Store the current cursor position
                int oldX = x;
                int oldY = y;
                
                // Check if the pressed key has an associated action
                if (myControls.ContainsKey(key.Key))
                {
                    // Execute the associated action for the pressed key
                    movement move = new movement(myControls[key.Key]);
                    move();
                }
                else if (key.Key == ConsoleKey.OemPeriod)
                {
                    // If the period key is pressed, terminate the application
                    Environment.Exit(0);
                }

                // Reset the cursor to its previous position and display the character '+'
                Console.SetCursorPosition(oldX, oldY);
                Console.Write("+");
            }
        }

        private static void Right()
        {
            // Move the cursor to the right
            x++;
        }

        private static void Left()
        {
            // Move the cursor to the left
            x--;
        }

        private static void Down()
        {
            // Move the cursor down
            y++;
        }

        private static void Up()
        {
            // Move the cursor up
            y--;
        }
    }
}
